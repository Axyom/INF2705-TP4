#include "VueStereo.h"

SINGLETON_DECLARATION_CPP(VueStereo);

GLdouble VueStereo::dip = 0.80;
GLdouble VueStereo::factzoom = 1.0;
GLdouble VueStereo::zavant = 1.0;
GLdouble VueStereo::zarriere = 20.0;
GLdouble VueStereo::zecran = 10.0;
